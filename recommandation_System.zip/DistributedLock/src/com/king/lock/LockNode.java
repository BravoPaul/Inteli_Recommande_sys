package com.king.lock;

public class LockNode implements Comparable<LockNode>{
	
	String id;

	public LockNode(String id) {
		super();
		this.id = id;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public int compareTo(LockNode o) {
		// TODO Auto-generated method stub
		return id.compareTo(o.getName());
	}
	
}
